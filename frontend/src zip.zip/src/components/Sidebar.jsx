import { Link } from "react-router-dom";
import {
  FaHome,
  FaPills,
  FaTruck,
  FaBoxes,
  FaClipboardList,
  FaBell,
  FaChartBar,
  FaHistory,
  FaClock,
  FaSignOutAlt
} from "react-icons/fa";

import "../css/Sidebar.css";

function Sidebar({ role, logout }) {
  return (
    <div className="sidebar">

      <div className="logo">

        <h2>🏥 MediStock</h2>

        <p>Medical Inventory</p>

      </div>

      <ul>

        <li>
          <Link to="/dashboard">
            <FaHome /> Dashboard
          </Link>
        </li>

        {(role === "ADMIN" || role === "PHARMACIST") && (
          <li>
            <Link to="/medicines">
              <FaPills /> Medicines
            </Link>
          </li>
        )}

        {role === "ADMIN" && (
          <li>
            <Link to="/suppliers">
              <FaTruck /> Suppliers
            </Link>
          </li>
        )}

        <li>
          <Link to="/inventory">
            <FaBoxes /> Inventory
          </Link>
        </li>

        <li>
          <Link to="/purchaseorders">
            <FaClipboardList /> Purchase Orders
          </Link>
        </li>

        {(role === "ADMIN" || role === "STAFF") && (
          <li>
            <Link to="/stocklogs">
              <FaHistory /> Stock Logs
            </Link>
          </li>
        )}

        {(role === "ADMIN" || role === "PHARMACIST") && (
          <li>
            <Link to="/expirytracking">
              <FaClock /> Expiry Tracking
            </Link>
          </li>
        )}

        {(role === "ADMIN" || role === "STAFF") && (
          <li>
            <Link to="/notifications">
              <FaBell /> Notifications
            </Link>
          </li>
        )}

        {role === "ADMIN" && (
          <li>
            <Link to="/reports">
              <FaChartBar /> Reports
            </Link>
          </li>
        )}

      </ul>

      <button
        className="logout-side"
        onClick={logout}
      >
        <FaSignOutAlt /> Logout
      </button>

    </div>
  );
}

export default Sidebar;