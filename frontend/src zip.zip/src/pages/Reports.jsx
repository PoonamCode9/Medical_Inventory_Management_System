import { useEffect, useState } from "react";
import API from "../services/api";

function Reports() {

    const [reports, setReports] = useState([]);

    const [reportName, setReportName] = useState("");
    const [reportType, setReportType] = useState("");
    const [generatedDate, setGeneratedDate] = useState("");

    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        loadReports();
    }, []);

    const loadReports = async () => {

        try {

            const response = await API.get("/reports");

            setReports(response.data);

        } catch (error) {

            console.log(error);

        }

    };

    const addReport = async () => {

        try {

            if (editingId === null) {

                await API.post("/reports", {

                    reportName,
                    reportType,
                    generatedDate

                });

                alert("Report Added Successfully");

            } else {

                await API.put(`/reports/${editingId}`, {

                    reportName,
                    reportType,
                    generatedDate

                });

                alert("Report Updated Successfully");

                setEditingId(null);

            }

            setReportName("");
            setReportType("");
            setGeneratedDate("");

            loadReports();

        } catch (error) {

            console.log(error);

            alert("Operation Failed");

        }

    };

    const editReport = (report) => {

        setEditingId(report.id);

        setReportName(report.reportName);
        setReportType(report.reportType);
        setGeneratedDate(report.generatedDate);

    };

    const deleteReport = async (id) => {

        const confirmDelete = window.confirm(
            "Are you sure you want to delete this report?"
        );

        if (!confirmDelete) return;

        try {

            await API.delete(`/reports/${id}`);

            alert("Report Deleted Successfully");

            loadReports();

        } catch (error) {

            console.log(error);

            alert("Delete Failed");

        }

    };

    return (

        <div className="container mt-4">

            <h2 className="mb-4">Reports</h2>

            <div className="card p-4 mb-4">

                <h4>
                    {editingId === null ? "Add Report" : "Update Report"}
                </h4>

                <input
                    className="form-control mb-2"
                    placeholder="Report Name"
                    value={reportName}
                    onChange={(e) => setReportName(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    placeholder="Report Type"
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value)}
                />

                <input
                    className="form-control mb-3"
                    type="date"
                    value={generatedDate}
                    onChange={(e) => setGeneratedDate(e.target.value)}
                />

                <button
                    className="btn btn-success"
                    onClick={addReport}
                >
                    {editingId === null ? "Add Report" : "Update Report"}
                </button>

            </div>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Report Name</th>
                        <th>Report Type</th>
                        <th>Generated Date</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {
                        reports.map((report) => (

                            <tr key={report.id}>

                                <td>{report.id}</td>
                                <td>{report.reportName}</td>
                                <td>{report.reportType}</td>
                                <td>{report.generatedDate}</td>

                                <td>

                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => editReport(report)}
                                    >
                                        Edit
                                    </button>

                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => deleteReport(report.id)}
                                    >
                                        Delete
                                    </button>

                                </td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}

export default Reports;