import { useEffect, useState } from "react";
import API from "../services/api";

function Medicines() {

    const [medicines, setMedicines] = useState([]);

    const [medicineName, setMedicineName] = useState("");
    const [manufacturer, setManufacturer] = useState("");
    const [price, setPrice] = useState("");
    const [quantity, setQuantity] = useState("");
    const [expiryDate, setExpiryDate] = useState("");
    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        loadMedicines();
    }, []);

    const loadMedicines = async () => {

        try {

            const response = await API.get("/medicines");

            setMedicines(response.data);

        } catch (error) {

            console.log(error);

        }

    };

   const addMedicine = async () => {

    try {

        if (editingId === null) {

            await API.post("/medicines", {

                medicineName,
                manufacturer,
                price,
                quantity,
                expiryDate

            });

            alert("Medicine Added Successfully");

        } else {

            await API.put(`/medicines/${editingId}`, {

                medicineName,
                manufacturer,
                price,
                quantity,
                expiryDate

            });

            alert("Medicine Updated Successfully");

            setEditingId(null);

        }

        setMedicineName("");
        setManufacturer("");
        setPrice("");
        setQuantity("");
        setExpiryDate("");

        loadMedicines();

    } catch (error) {

        console.log(error);

        alert("Operation Failed");

    }

};

     const deleteMedicine = async (id) => {

    const confirmDelete = window.confirm(
        "Are you sure you want to delete this medicine?"
    );

    if (!confirmDelete) {
        return;
    }

    try {

        await API.delete(`/medicines/${id}`);

        alert("Medicine Deleted Successfully");

        loadMedicines();

    } catch (error) {

        console.log(error);

        alert("Failed to Delete Medicine");

    }

};

const editMedicine = (medicine) => {

    setEditingId(medicine.id);

    setMedicineName(medicine.medicineName);
    setManufacturer(medicine.manufacturer);
    setPrice(medicine.price);
    setQuantity(medicine.quantity);
    setExpiryDate(medicine.expiryDate);

};

    return (

        <div className="container mt-4">

            <h2 className="mb-4">Medicines</h2>

            <div className="card p-4 mb-4">

                <h4>Add Medicine</h4>

                <input
                    className="form-control mb-2"
                    placeholder="Medicine Name"
                    value={medicineName}
                    onChange={(e) => setMedicineName(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    placeholder="Manufacturer"
                    value={manufacturer}
                    onChange={(e) => setManufacturer(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    type="number"
                    placeholder="Price"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    type="number"
                    placeholder="Quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                />

                <input
                    className="form-control mb-3"
                    type="date"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                />

                <button
                    className="btn btn-success"
                    onClick={addMedicine}
                >
                    {editingId === null ? "Add Medicine" : "Update Medicine"}
                </button>

            </div>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Name</th>
                        <th>Manufacturer</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Expiry Date</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {
                        medicines.map((medicine) => (

                            <tr key={medicine.id}>

                                <td>{medicine.id}</td>
                                <td>{medicine.medicineName}</td>
                                <td>{medicine.manufacturer}</td>
                                <td>{medicine.price}</td>
                                <td>{medicine.quantity}</td>
                                <td>{medicine.expiryDate}</td>
                                <td>

    <button
        className="btn btn-warning btn-sm me-2"
        onClick={() => editMedicine(medicine)}
    >
        Edit
    </button>

    <button
        className="btn btn-danger btn-sm"
        onClick={() => deleteMedicine(medicine.id)}
    >
        Delete
    </button>

</td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}

export default Medicines;