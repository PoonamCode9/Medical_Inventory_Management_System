import { useEffect, useState } from "react";
import API from "../services/api";

function Notifications() {

    const [notifications, setNotifications] = useState([]);

    const [title, setTitle] = useState("");
    const [message, setMessage] = useState("");
    const [date, setDate] = useState("");

    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        loadNotifications();
    }, []);

    const loadNotifications = async () => {

        try {

            const response = await API.get("/notifications");

            setNotifications(response.data);

        } catch (error) {

            console.log(error);

        }

    };

    const addNotification = async () => {

        try {

            if (editingId === null) {

                await API.post("/notifications", {

                    title,
                    message,
                    date

                });

                alert("Notification Added Successfully");

            } else {

                await API.put(`/notifications/${editingId}`, {

                    title,
                    message,
                    date

                });

                alert("Notification Updated Successfully");

                setEditingId(null);

            }

            setTitle("");
            setMessage("");
            setDate("");

            loadNotifications();

        } catch (error) {

            console.log(error);

            alert("Operation Failed");

        }

    };

    const editNotification = (notification) => {

        setEditingId(notification.id);

        setTitle(notification.title);
        setMessage(notification.message);
        setDate(notification.date);

    };

    const deleteNotification = async (id) => {

        const confirmDelete = window.confirm(
            "Are you sure you want to delete this notification?"
        );

        if (!confirmDelete) return;

        try {

            await API.delete(`/notifications/${id}`);

            alert("Notification Deleted Successfully");

            loadNotifications();

        } catch (error) {

            console.log(error);

            alert("Delete Failed");

        }

    };

    return (

        <div className="container mt-4">

            <h2 className="mb-4">Notifications</h2>

            <div className="card p-4 mb-4">

                <h4>
                    {editingId === null ? "Add Notification" : "Update Notification"}
                </h4>

                <input
                    className="form-control mb-2"
                    placeholder="Title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />

                <textarea
                    className="form-control mb-2"
                    placeholder="Message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                />

                <input
                    className="form-control mb-3"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                />

                <button
                    className="btn btn-success"
                    onClick={addNotification}
                >
                    {editingId === null ? "Add Notification" : "Update Notification"}
                </button>

            </div>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Title</th>
                        <th>Message</th>
                        <th>Date</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {
                        notifications.map((notification) => (

                            <tr key={notification.id}>

                                <td>{notification.id}</td>
                                <td>{notification.title}</td>
                                <td>{notification.message}</td>
                                <td>{notification.date}</td>

                                <td>

                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => editNotification(notification)}
                                    >
                                        Edit
                                    </button>

                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => deleteNotification(notification.id)}
                                    >
                                        Delete
                                    </button>

                                </td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}

export default Notifications;