import { useEffect, useState } from "react";
import API from "../services/api";

function Suppliers() {

    const [suppliers, setSuppliers] = useState([]);

    const [supplierName, setSupplierName] = useState("");
    const [contactNumber, setContactNumber] = useState("");
    const [email, setEmail] = useState("");
    const [address, setAddress] = useState("");

    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        loadSuppliers();
    }, []);

    const loadSuppliers = async () => {

        try {

            const response = await API.get("/suppliers");

            setSuppliers(response.data);

        } catch (error) {

            console.log(error);

        }

    };

    const addSupplier = async () => {

        try {

            if (editingId === null) {

                await API.post("/suppliers", {

                    supplierName,
                    contactNumber,
                    email,
                    address

                });

                alert("Supplier Added Successfully");

            } else {

                await API.put(`/suppliers/${editingId}`, {

                    supplierName,
                    contactNumber,
                    email,
                    address

                });

                alert("Supplier Updated Successfully");

                setEditingId(null);

            }

            setSupplierName("");
            setContactNumber("");
            setEmail("");
            setAddress("");

            loadSuppliers();

        } catch (error) {

            console.log(error);

            alert("Operation Failed");

        }

    };

    const editSupplier = (supplier) => {

        setEditingId(supplier.id);

        setSupplierName(supplier.supplierName);
        setContactNumber(supplier.contactNumber);
        setEmail(supplier.email);
        setAddress(supplier.address);

    };

    const deleteSupplier = async (id) => {

        const confirmDelete = window.confirm(
            "Are you sure you want to delete this supplier?"
        );

        if (!confirmDelete) {
            return;
        }

        try {

            await API.delete(`/suppliers/${id}`);

            alert("Supplier Deleted Successfully");

            loadSuppliers();

        } catch (error) {

            console.log(error);

            alert("Failed to Delete Supplier");

        }

    };

    return (

        <div className="container mt-4">

            <h2 className="mb-4">Suppliers</h2>

            <div className="card p-4 mb-4">

                <h4>Add Supplier</h4>

                <input
                    className="form-control mb-2"
                    placeholder="Supplier Name"
                    value={supplierName}
                    onChange={(e) => setSupplierName(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    placeholder="Contact Number"
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

                <textarea
                    className="form-control mb-3"
                    placeholder="Address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                />

                <button
                    className="btn btn-success"
                    onClick={addSupplier}
                >
                    {editingId === null ? "Add Supplier" : "Update Supplier"}
                </button>

            </div>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Supplier Name</th>
                        <th>Contact Number</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {
                        suppliers.map((supplier) => (

                            <tr key={supplier.id}>

                                <td>{supplier.id}</td>
                                <td>{supplier.supplierName}</td>
                                <td>{supplier.contactNumber}</td>
                                <td>{supplier.email}</td>
                                <td>{supplier.address}</td>

                                <td>

                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => editSupplier(supplier)}
                                    >
                                        Edit
                                    </button>

                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => deleteSupplier(supplier.id)}
                                    >
                                        Delete
                                    </button>

                                </td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}

export default Suppliers;