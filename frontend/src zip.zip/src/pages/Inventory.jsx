import { useEffect, useState } from "react";
import API from "../services/api";

function Inventory() {

    const [inventory, setInventory] = useState([]);

    useEffect(() => {
        loadInventory();
    }, []);

    const loadInventory = async () => {

        try {

            const response = await API.get("/inventory");

            setInventory(response.data);

        } catch (error) {

            console.log(error);

        }

    };

    return (

        <div className="container mt-4">

            <h2 className="mb-4">Inventory</h2>

            <table className="table table-bordered table-striped">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Medicine Name</th>
                        <th>Available Stock</th>
                        <th>Minimum Stock</th>

                    </tr>

                </thead>

                <tbody>

                    {
                        inventory.map((item) => (

                            <tr key={item.id}>

                                <td>{item.id}</td>

                                <td>{item.medicine?.medicineName}</td>

                                <td>{item.availableStock}</td>

                                <td>{item.minimumStock}</td>

                            </tr>

                        ))
                    }

                </tbody>

            </table>

        </div>

    );

}

export default Inventory;