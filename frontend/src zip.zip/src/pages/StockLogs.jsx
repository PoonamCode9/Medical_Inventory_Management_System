import { useEffect, useState } from "react";
import API from "../services/api";

function StockLogs() {

    const [stockLogs, setStockLogs] = useState([]);

    const [action, setAction] = useState("");
    const [quantity, setQuantity] = useState("");
    const [date, setDate] = useState("");
    const [medicineId, setMedicineId] = useState("");

    const [editingId, setEditingId] = useState(null);

    useEffect(() => {
        loadStockLogs();
    }, []);

    const loadStockLogs = async () => {

        try {

            const response = await API.get("/stocklogs");

            setStockLogs(response.data);

        } catch (error) {

            console.log(error);

        }

    };

    const saveStockLog = async () => {

        const stockLog = {

            action,
            quantity,
            date,

            medicine: {
                id: medicineId
            }

        };

        try {

            if (editingId === null) {

                await API.post("/stocklogs", stockLog);

                alert("Stock Log Added Successfully");

            } else {

                await API.put(`/stocklogs/${editingId}`, stockLog);

                alert("Stock Log Updated Successfully");

            }

            clearForm();

            loadStockLogs();

        } catch (error) {

            console.log(error);

        }

    };

    const editStockLog = (log) => {

        setEditingId(log.id);

        setAction(log.action);

        setQuantity(log.quantity);

        setDate(log.date);

        setMedicineId(log.medicine?.id);

    };

    const deleteStockLog = async (id) => {

        if (window.confirm("Delete this Stock Log?")) {

            await API.delete(`/stocklogs/${id}`);

            alert("Deleted Successfully");

            loadStockLogs();

        }

    };

    const clearForm = () => {

        setEditingId(null);

        setAction("");

        setQuantity("");

        setDate("");

        setMedicineId("");

    };

    return (

        <div className="container mt-4">

            <h2>Stock Logs</h2>

            <div className="card p-3 mb-4">

                <input
                    className="form-control mb-2"
                    placeholder="Action"
                    value={action}
                    onChange={(e) => setAction(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    placeholder="Quantity"
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                />

                <input
                    className="form-control mb-2"
                    placeholder="Medicine ID"
                    type="number"
                    value={medicineId}
                    onChange={(e) => setMedicineId(e.target.value)}
                />

                <button
                    className="btn btn-primary"
                    onClick={saveStockLog}
                >

                    {editingId === null ? "Add Stock Log" : "Update Stock Log"}

                </button>

            </div>

            <table className="table table-bordered">

                <thead>

                    <tr>

                        <th>ID</th>
                        <th>Action</th>
                        <th>Quantity</th>
                        <th>Date</th>
                        <th>Medicine ID</th>
                        <th>Actions</th>

                    </tr>

                </thead>

                <tbody>

                    {

                        stockLogs.map((log) => (

                            <tr key={log.id}>

                                <td>{log.id}</td>

                                <td>{log.action}</td>

                                <td>{log.quantity}</td>

                                <td>{log.date}</td>

                                <td>{log.medicine?.id}</td>

                                <td>

                                    <button
                                        className="btn btn-warning btn-sm me-2"
                                        onClick={() => editStockLog(log)}
                                    >
                                        Edit
                                    </button>

                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => deleteStockLog(log.id)}
                                    >
                                        Delete
                                    </button>

                                </td>

                            </tr>

                        ))

                    }

                </tbody>

            </table>

        </div>

    );

}

export default StockLogs;