import { Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import "../css/Dashboard.css";
import Sidebar from "../components/Sidebar";

function Dashboard() {

  const navigate = useNavigate();

  const name = localStorage.getItem("name");
  const role = localStorage.getItem("role");

  useEffect(() => {

    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/");
    }

  }, [navigate]);

  const logout = () => {

    localStorage.clear();

    alert("Logged Out Successfully");

    navigate("/");

  };

  return (

    <>

      <Sidebar role={role} logout={logout} />

      <div className="dashboard-content">

        <div className="container mt-4">

          <div className="d-flex justify-content-between align-items-center mb-4">

            <div>

              <h2 className="dashboard-title">
                🏥 MediStock Dashboard
              </h2>

              <h5 className="welcome-text">
                Welcome, {name}
              </h5>

              <div className="role-badge">
                {role}
              </div>

            </div>

          </div>

          <div className="row">

            {(role === "ADMIN" || role === "PHARMACIST") && (
              <div className="col-md-4 mb-3">
                <Link to="/medicines" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>💊 Medicines</h4>
                  </div>
                </Link>
              </div>
            )}

            {role === "ADMIN" && (
              <div className="col-md-4 mb-3">
                <Link to="/suppliers" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>🚚 Suppliers</h4>
                  </div>
                </Link>
              </div>
            )}

            {(role === "ADMIN" || role === "PHARMACIST" || role === "STAFF") && (
              <div className="col-md-4 mb-3">
                <Link to="/inventory" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>📦 Inventory</h4>
                  </div>
                </Link>
              </div>
            )}

            {(role === "ADMIN" || role === "STAFF") && (
              <div className="col-md-4 mb-3">
                <Link to="/stocklogs" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>📦 Stock Logs</h4>
                  </div>
                </Link>
              </div>
            )}

            {role === "ADMIN" && (
              <div className="col-md-4 mb-3">
                <Link to="/purchaseorders" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>📋 Purchase Orders</h4>
                  </div>
                </Link>
              </div>
            )}

            {(role === "ADMIN" || role === "PHARMACIST") && (
              <div className="col-md-4 mb-3">
                <Link to="/expirytracking" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>⏰ Expiry Tracking</h4>
                  </div>
                </Link>
              </div>
            )}

            {(role === "ADMIN" || role === "STAFF") && (
              <div className="col-md-4 mb-3">
                <Link to="/notifications" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>🔔 Notifications</h4>
                  </div>
                </Link>
              </div>
            )}

            {role === "ADMIN" && (
              <div className="col-md-4 mb-3">
                <Link to="/reports" className="text-decoration-none">
                  <div className="card shadow dashboard-card text-center p-4">
                    <h4>📊 Reports</h4>
                  </div>
                </Link>
              </div>
            )}

          </div>

        </div>

      </div>

    </>

  );
}

export default Dashboard;